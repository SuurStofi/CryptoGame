# Marketplace App (React + Vite + Tailwind)

## How to Run on Windows

1. Install Node.js from https://nodejs.org (includes npm)
2. Unzip this folder
3. Open PowerShell or CMD in the folder and run:
   ```bash
   npm install
   npm run dev
   ```
4. Open the printed URL (e.g., http://localhost:5173)

---
Everything (React + Tailwind + lucide-react) is preconfigured.
